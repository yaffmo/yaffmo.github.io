(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.ss01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC00").s().p("AgEEAQAAhIgTg8QgSg8gegZQgVgRgWAEQgFABgBgFIAAgBQAAgFAEgBQAVgDAUgWQAVgXAQgmQAihSAAhmQAAgGAEAAQAFAAAAAGQAABmAiBSQAQAmAVAXQAUAWAVADQAEABAAAFIAAABQgBAFgFgBQgWgEgUARQgfAZgSA8QgTA8AABIQAAAGgFAAQgEAAAAgGg");
	this.shape.setTransform(0,0,1.383,1.383);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.7,-36.2,33.6,72.5);


(lib.smoke0000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AiXCYQg/g/ABhZQgBhYA/g/QA/g/BYABQBZgBA/A/QA/A/gBBYQABBZg/A/Qg/A/hZgBQhYABg/g/g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.4,-21.4,42.9,42.9);


(lib.smoke0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AiXCYQg/g/ABhZQgBhYA/g/QA/g/BYABQBZgBA/A/QA/A/gBBYQABBZg/A/Qg/A/hZgBQhYABg/g/g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.4,-21.4,42.9,42.9);


(lib.light00 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC00").s().p("AJILHQAfgeAegmIAgAZQgdAngjAhgArOJlIAigXQAqBAA6A5IgcAdQg6g6gwhFgALcH+QAmhGAWhMIAnALQgYBQgnBKgAtQE0IApgIQAOBJAhBOIgmAQQgfhMgThTgAM2DRQAEgoAAgqQAAgtgEggIAqgDQADArAAAlQAAAsgEAqgAtiB/QAAhLANhJIAnAHQgMBFAABIIABAPIgpACgALej7IAkgTQAnBKAXBRIgnALQgVhKgmhJgAspi1QAdhOAthHIAiAWQgqBDgcBKgAJInIQgTgUgagWIAbgfQAUARAbAbQAkAkAfAoIgfAZQgdglgkgjgAp7nOIAXgXQAwgwA2gnIAXAhQgwAjgxAwIgWAWgAEKqOIANgnQBPAbBJAqIgWAiQhHgohIgYgAlwqRQBMgjBQgUIAKAnQhKAShLAjgAgtq5IgDgoQBTgGBSAMIgGAoQhOgKhOAEg");
	this.shape.setTransform(0,-8.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-86.7,-82.3,173.4,148.1);


(lib.fire01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E84042").s().p("Ah7DfQg0g0AAhJQAAhJA1hxQA2hzBEhGQBIBJA2BxQAyBugBBLQABBJgzA0QgzAyhKAAQhHAAg0gyg");
	this.shape.setTransform(0,-33.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E84042").s().p("Ah2DWQgygxAAhHQAAhGAzhtQA0hvBBhDQBGBGAzBtQAwBqAABIQAABHgxAxQgxAyhHAAQhFAAgxgyg");
	this.shape_1.setTransform(-0.1,-32.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E84042").s().p("AhyDOQgwgwAAhEQAAhEAxhoQAzhrA+hAQBDBCAyBqQAuBmAABFQAABEgvAwQgwAwhEAAQhDAAgvgwg");
	this.shape_2.setTransform(0,-31.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E84042").s().p("AhtDHQgvguAAhBQAAhCAwhkQAwhnA8g+QBABAAwBmQAtBhAABEQAABBguAuQgtAthCAAQhAAAgtgtg");
	this.shape_3.setTransform(-0.1,-30.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E84042").s().p("AhpC/QgtgtAAg+QAAg/AuhgQAuhjA6g8QA9A+AvBiQArBdAABBQAAA+gsAtQgsArg/AAQg9AAgsgrg");
	this.shape_4.setTransform(0,-29.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E84042").s().p("AhlC3QgqgqAAg9QAAg8ArhcQAthfA3g5QA7A7AsBeQApBZAAA+QAAA9gpAqQgrAqg8AAQg6AAgrgqg");
	this.shape_5.setTransform(-0.1,-28.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E84042").s().p("AhhCuQgognAAg7QAAg5AphYQArhbA1g2QA5A4AqBaQAnBVAAA7QAAA7goAnQgoApg6AAQg4AAgpgpg");
	this.shape_6.setTransform(0,-27.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E84042").s().p("AhcCnQgngmAAg3QAAg3AohUQAphXAyg0QA2A2AoBVQAmBSAAA5QAAA3gmAmQgnAmg3AAQg1AAgngmg");
	this.shape_7.setTransform(-0.1,-27.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E84042").s().p("AhYCfQglglAAg0QAAg1AmhPQAnhTAwgyQAzA0AnBRQAkBOAAA2QAAA0glAlQglAlg0AAQgzAAglglg");
	this.shape_8.setTransform(0,-26.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E84042").s().p("AhTCXQgjgjAAgyQAAgxAkhMQAlhPAtgvQAxAxAkBNQAiBKAAAzQAAAygiAjQgjAjgyAAQgwAAgjgjg");
	this.shape_9.setTransform(-0.1,-25.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E84042").s().p("AhbClQgngmAAg2QAAg3AohTQAohWAygzQA1A1AoBVQAmBRgBA4QAAA2gmAmQgmAmg2AAQg1AAgmgmg");
	this.shape_10.setTransform(0,-26.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E84042").s().p("AhjC0QgqgqAAg7QAAg7ArhbQAshdA2g4QA6A6ArBcQApBYAAA9QAAA7gpAqQgqApg7AAQg5AAgqgpg");
	this.shape_11.setTransform(-0.1,-28.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#E84042").s().p("AhrDBQgtgsAAhAQAAg/AuhiQAvhmA7g8QA/A/AuBjQAsBgAABBQAABAgsAsQgtAthAAAQg+AAgtgtg");
	this.shape_12.setTransform(0,-30.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E84042").s().p("AhyDQQgxgwAAhFQAAhEAyhpQAyhsA/hBQBEBEAyBqQAuBmAABGQAABFgvAwQgwAwhFAAQhDAAgvgwg");
	this.shape_13.setTransform(-0.1,-31.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape}]},1).wait(1));

	// 圖層 3
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#EB6C85").s().p("Ai+FVQhPhPAAhwQAAhxBRitQBTixBphqQBuBuBRCwQBPCoAABzQAABwhPBPQhQBPhvAAQhvAAhPhPg");
	this.shape_14.setTransform(0,-44.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#EB6C85").s().p("AjCFdQhRhRAAhyQAAh0BTixQBVi2BrhsQBxBxBTC0QBQCsAAB2QAAByhRBRQhRBRhyAAQhyAAhQhRg");
	this.shape_15.setTransform(0,-45.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#EB6C85").s().p("AjHFkQhShSAAh1QAAh3BUi0QBXi6BuhvQBzB0BVC3QBSCxAAB4QAAB1hSBSQhTBUh1AAQh0AAhThUg");
	this.shape_16.setTransform(0,-46.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#EB6C85").s().p("AjMFtQhUhUAAh4QAAh5BXi6QBYi9BxhyQB1B3BYC7QBUC1AAB7QAAB4hVBUQhVBVh3gBQh3ABhVhVg");
	this.shape_17.setTransform(0.1,-47.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#EB6C85").s().p("AjQF1QhWhWAAh6QAAh9BZi8QBajCBzh0QB4B4BZDAQBWC5AAB+QAAB6hWBWQhXBWh6AAQh5AAhXhWg");
	this.shape_18.setTransform(0.1,-48.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#EB6C85").s().p("AjUF9QhZhYAAh9QAAh/BbjBQBdjGB1h2QB7B7BaDEQBZC8gBCBQAAB9hYBYQhZBYh8AAQh8AAhYhYg");
	this.shape_19.setTransform(0.1,-49);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#EB6C85").s().p("AjZGFQhahaAAiAQAAiBBdjFQBejKB4h5QB9B+BdDIQBaDAAACDQAACAhaBaQhbBah/AAQh+AAhbhag");
	this.shape_20.setTransform(0.1,-49.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#EB6C85").s().p("AjVF/QhZhZAAh+QAAh/BbjCQBdjHB3h2QB6B7BcDFQBYC9AACBQAAB+hZBZQhYBZh9AAQh+AAhYhZg");
	this.shape_21.setTransform(0.1,-49.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#EB6C85").s().p("AjSF5QhXhXAAh8QAAh9Bai/QBbjEB0h1QB6B5BaDDQBWC6AAB/QAAB8hXBXQhYBXh7AAQh6AAhYhXg");
	this.shape_22.setTransform(0.1,-48.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#EB6C85").s().p("AjPFzQhVhWgBh6QAAh7BZi8QBajBByhzQB4B4BYC/QBWC3AAB9QAAB6hWBWQhXBWh5AAQh5AAhWhWg");
	this.shape_23.setTransform(0.1,-48);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#EB6C85").s().p("AjIFnQhThTAAh2QAAh3BVi2QBXi7BvhvQB0B0BVC5QBTCxAAB5QAAB2hUBTQhTBTh1AAQh1AAhThTg");
	this.shape_24.setTransform(0.1,-46.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#EB6C85").s().p("AjFFhQhRhSAAhzQAAh2BUiyQBVi4BthuQByByBUC2QBRCuAAB4QAABzhSBSQhSBShzAAQhzAAhShSg");
	this.shape_25.setTransform(0,-46.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#EB6C85").s().p("AjBFaQhRhPAAhyQABh0BSivQBUi1BrhrQBvBwBTCyQBQCsAAB1QABByhRBPQhRBRhxAAQhxAAhQhRg");
	this.shape_26.setTransform(0,-45.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14}]}).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_14}]},1).wait(1));

	// 圖層 4
	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFEF3").s().p("AkTHuQhzhyAAiiQAAilB2j6QB4kBCYiZQCgCgB1D+QBxD0ABCnQgBCihyByQhzByihAAQiiAAhxhyg");
	this.shape_27.setTransform(0,-60.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFEF3").s().p("AkQHoQhxhxABigQAAijB0j3QB1j9CXiYQCeCfB0D6QBvDyAACkQAACghwBxQhyBxifAAQifAAhxhxg");
	this.shape_28.setTransform(0,-60.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFEF3").s().p("AkNHiQhvhvAAieQAAihBzj1QB0j5CViWQCcCdByD3QBvDuAACjQAACehwBvQhwBvidAAQieAAhvhvg");
	this.shape_29.setTransform(0,-59.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFEF3").s().p("AkJHcQhuhvAAibQAAifBxjxQB0j3CSiTQCaCaBwD0QBuDsAACgQAACbhvBvQhtBuicAAQibAAhuhug");
	this.shape_30.setTransform(0,-58.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFEF3").s().p("AkGHVQhshsAAiaQAAicBwjuQByj0CQiSQCYCZBvDxQBsDoAACeQAACahsBsQhtBtiaAAQiZAAhthtg");
	this.shape_31.setTransform(0,-58.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFEF3").s().p("AkCHPQhrhrAAiYQAAiaBujrQBwjwCPiRQCWCXBtDuQBrDmAACbQAACYhrBrQhrBsiYgBQiXABhrhsg");
	this.shape_32.setTransform(0,-57.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFEF3").s().p("Aj/HJQhphpAAiWQAAiZBsjnQBvjtCNiPQCUCVBsDrQBpDiAACaQAACWhqBpQhqBqiVAAQiVAAhqhqg");
	this.shape_33.setTransform(0,-56.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFEF3").s().p("Aj7HDQhphoABiUQgBiWBsjlQBtjqCLiMQCSCSBrDoQBnDfAACYQABCUhpBoQhpBoiTAAQiTAAhohog");
	this.shape_34.setTransform(0,-56);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFEF3").s().p("Aj3G9QhohnAAiSQAAiUBqjhQBsjnCJiKQCQCQBpDkQBmDcABCWQAACShoBnQhnBniRgBQiRABhmhng");
	this.shape_35.setTransform(0,-55.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFEF3").s().p("Aj8HFQhphpAAiUQAAiXBsjmQBtjrCMiNQCSCUBsDoQBoDgAACZQAACUhpBpQhpBpiUAAQiUAAhohpg");
	this.shape_36.setTransform(0,-56.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFEF3").s().p("AkBHNQhrhqAAiXQAAiaBujqQBwjvCOiQQCWCWBsDtQBqDkABCcQAACXhsBqQhqBriXAAQiXAAhqhrg");
	this.shape_37.setTransform(0,-57.2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFEF3").s().p("AkKHdQhuhuAAicQgBifByjyQBzj5CUiUQCbCbBwD1QBuDtAAChQAACchuBuQhvBvicAAQicAAhuhvg");
	this.shape_38.setTransform(0,-59);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFEF3").s().p("AkPHmQhwhwAAifQAAijB0j2QB1j8CWiXQCdCeB0D5QBvDxAACkQAACfhwBwQhxBwifAAQieAAhxhwg");
	this.shape_39.setTransform(0,-59.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27}]}).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_27}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-121.6,78.1,121.7);


(lib.ss02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.instance = new lib.ss01("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.057,0.057);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1},4).to({scaleX:0.07,scaleY:0.07},5).to({_off:true},1).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.9,-2.1,1.9,4.1);


(lib.smoke010 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.instance = new lib.smoke0000("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.411,0.411);
	this.instance.alpha = 0.238;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.58,scaleY:0.58,x:19.1,y:-38.7,alpha:1},6).to({scaleX:0.79,scaleY:0.79,x:-11.2,y:-87.1},7).to({regY:-0.3,scaleX:1.26,scaleY:1.26,x:0,y:-135.6,alpha:0.051},6).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.8,-8.8,17.6,17.6);


(lib.smoke01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.instance = new lib.smoke0("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.411,0.411);
	this.instance.alpha = 0.238;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.58,scaleY:0.58,x:19.1,y:-38.7,alpha:1},6).to({scaleX:0.79,scaleY:0.79,x:-11.2,y:-87.1},7).to({regY:-0.3,scaleX:1.26,scaleY:1.26,x:0,y:-135.6,alpha:0.051},6).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.8,-8.8,17.6,17.6);


(lib.smoke000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 4
	this.instance = new lib.smoke01("synched",0,false);
	this.instance.parent = this;
	this.instance.setTransform(-6.4,31,0.78,0.78);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({_off:false},0).wait(34));

	// 圖層 8
	this.instance_1 = new lib.smoke010("synched",0,false);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-4.3,17,0.484,0.484,0,2.8,-177.2,0.1,0.8);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(8).to({_off:false},0).wait(32));

	// 圖層 3
	this.instance_2 = new lib.smoke010("synched",0,false);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-4.4,34.5,0.859,0.859,0,-11,169,-0.1,0.1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3).to({_off:false},0).wait(37));

	// 圖層 2
	this.instance_3 = new lib.smoke01("synched",0,false);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-6.4,31,1,1,6);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(40));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.2,22.2,17.6,17.6);


(lib.light002 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.instance = new lib.light00("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,-1.1,0.735,0.735);
	this.instance.alpha = 0.031;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:-0.1,scaleX:1.18,scaleY:1.18,alpha:1},14).to({regY:0,scaleX:1.53,scaleY:1.53,y:-1,alpha:0.031},14).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.6,-61.6,127.4,108.8);


(lib.stlight = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 3
	this.instance = new lib.ss02("synched",7);
	this.instance.parent = this;
	this.instance.setTransform(162.5,4.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(30));

	// 圖層 2
	this.instance_1 = new lib.ss02("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(150.5,161.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(30));

	// 圖層 1
	this.instance_2 = new lib.ss02("synched",10);
	this.instance_2.parent = this;
	this.instance_2.setTransform(14.1,26.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(149.5,-11.9,20.3,174.9);


(lib.light0002 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 2
	this.instance = new lib.light002("synched",27);
	this.instance.parent = this;
	this.instance.setTransform(0,13.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(30));

	// 圖層 1
	this.instance_1 = new lib.light002("synched",13);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,13.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130.2,-111.2,260.5,222.4);


(lib.Candlelight_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 4
	this.instance = new lib.smoke000("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0.6,-215.5,0.671,0.671,0,0,0,-3.6,19.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(31).to({_off:false},0).to({_off:true},28).wait(1));

	// light0002
	this.instance_1 = new lib.light0002();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-2.3,-265,1,1,0,0,0,0,4);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},35).wait(25));

	// stlight
	this.instance_2 = new lib.stlight();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-95,-368.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},35).wait(25));

	// 圖層 3
	this.instance_3 = new lib.fire01();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0.2,-204);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(14).to({regX:0.1,scaleY:1.1,skewX:-24.3,x:0.3},4).to({scaleY:1.03,skewX:-14.7,x:0.4},4).to({regX:0.3,regY:-0.1,scaleX:0.93,scaleY:1.01,skewX:-24.3,x:0.5,y:-204.1},3).to({regX:0.2,regY:-0.3,scaleX:0.88,scaleY:1.09,skewX:-35.9,x:0.2,y:-204.3},3).to({regX:0.3,regY:0,scaleX:0.66,scaleY:0.7,skewX:-19.5,x:0.7,y:-204},3).to({regX:1.1,regY:-0.5,scaleX:0.22,scaleY:0.23,skewX:-17.1,x:0.6,y:-219},3,cjs.Ease.get(-1)).to({_off:true},1).wait(25));

	// 圖層 8
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AgOAMIAAgXIAeAAIAAAXg");
	this.shape.setTransform(-0.2,-209.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgOAyIAAhHIAAgJIAAgTIAeAAIAAATIAAAJIAABHg");
	this.shape_1.setTransform(-0.2,-203.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AgOALIAAgVIAeAAIAAAVg");
	this.shape_2.setTransform(-0.2,-214.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFF00").s().p("AgOAHIAAgFQAOgRAQARIAAAFg");
	this.shape_3.setTransform(-0.2,-216);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF0000").s().p("AgOALIAAgCIAAgDIAAgFIAAgLIAeAAIAAALIAAAFIAAADIAAACg");
	this.shape_4.setTransform(-0.2,-211.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-104.9,-400.3,205.3,221.6);


// stage content:
(lib.Candlelight = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.instance = new lib.Candlelight_1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(132.3,418.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(129.7,168.2,260.5,222.4);
// library properties:
lib.properties = {
	id: '41C42613A88201469BBE0E7CCB5DE16D',
	width: 260,
	height: 260,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['42C42613A88201469BBE0E7CCB5DE16D'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;