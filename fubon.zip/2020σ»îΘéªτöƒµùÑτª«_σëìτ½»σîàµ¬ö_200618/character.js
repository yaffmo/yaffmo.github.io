(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.windqq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CCEFF").s().p("Ar4CkIAAlHIXxAAIAAFHg");
	this.shape.setTransform(74.7,15.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.4,-1.1,152.3,32.8);


(lib.wind00 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CCEFF").s().p("AgOAPQgGgGAAgJQAAgHAGgHQAGgGAIAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgHAAgHgGgAgGgGQgEADAAADQABAFADADQADADADAAQAEAAAEgEQADgDAAgEQAAgDgDgEQgEgDgEAAQgDAAgDAEg");
	this.shape.setTransform(0,0,3.663,3.663);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.8,-7.7,15.6,15.6);


(lib.shoe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EB6C85").s().p("Ai7BwQgXAAgTgPQgTgPgFgXQgFgZALgXQAMgUAWgKIDihcIDyAAIgGDfg");
	this.shape.setTransform(-1.4,12.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.9,1.5,51.1,22.3);


(lib.neck = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9CFB9").s().p("Ah0FbQhHgsgOhOIhElpQgOhOAyhDQAyhDBWgQIA6gLQBVgQBHAtQBHAsAOBOIBEFpQAOBOgyBDQgyBDhWAQIg6ALQgXAEgUAAQg9AAg0ghg");
	this.shape.setTransform(0,-26.1,0.687,0.687);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-18.7,-52.2,37.5,52.2);


(lib.mouth01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EB6C85").s().p("AAaAyQgkgBgfgeQgOgIgLgTQAMgPAcgNQAcgOARABQASABARAPQARAPgEAiQgEAigjAAIgCAAg");
	this.shape.setTransform(0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.6,-4.9,13.5,10);


(lib.leg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#215D9E").s().p("AnaVoQiNghg6hwQglhIABhgIEY+tQAvjGBjh6QDOj8F2BmQF+BmAdETQAJBYgcBpQgPA2gVA5IsQdgQgjBXhDAzQhFA0hZAAQgnAAgsgLg");
	this.shape.setTransform(-0.8,56.7,0.687,0.687);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-49.5,-39,97.5,191.5);


(lib.hat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5C71E").s().p("AgaAcIg7gLIAsgnIgIg8IAzAeIA3gZIgNA6IAqAqIg8AHIgbA1g");
	this.shape.setTransform(12.4,13.1,0.687,0.687);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F5C71E").s().p("AgaAcIg7gLIAsgnIgIg8IAzAeIA2gaIgLA7IApAqIg8AHIgbA1g");
	this.shape_1.setTransform(3.8,5.2,0.687,0.687);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F5C71E").s().p("AgaAcIg7gLIAtgnIgIg8IAzAeIA2gZIgNA6IAqArIg8AGIgbA0g");
	this.shape_2.setTransform(-4.9,-4,0.687,0.687);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F5C71E").s().p("AgaAcIg7gLIAtgnIgJg8IA0AeIA2gaIgNA7IAqAqIg8AHIgbA1g");
	this.shape_3.setTransform(-13.6,-12.5,0.687,0.687);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F5AB16").s().p("AgbAdIg9gLIAugpIgIg+IA1AgIA4gbIgNA9IArArIg+AHIgcA2g");
	this.shape_4.setTransform(15.5,15.3,0.687,0.687);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F5AB16").s().p("AgbAdIg9gMIAugoIgIg9IA1AeIA3gbIgMA9IArAsIg+AHIgcA3g");
	this.shape_5.setTransform(8.9,9,0.687,0.687);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F5AB16").s().p("AgbAdIg9gLIAugpIgIg+IA1AgIA4gbIgNA8IArAsIg+AHIgcA2g");
	this.shape_6.setTransform(-0.5,0.8,0.687,0.687);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F5AB16").s().p("AgbAcIg9gKIAugpIgIg9IA1AeIA4gbIgNA9IArAsIg+AGIgcA4g");
	this.shape_7.setTransform(-9.2,-7.8,0.687,0.687);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F5AB16").s().p("AgbAdIg9gLIAugpIgIg9IA1AeIA4gaIgNA8IArAsIg+AHIgcA2g");
	this.shape_8.setTransform(-16.7,-16.2,0.687,0.687);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EB6C85").s().p("AgnBWQgkgRgNglQgNgkAQgjQARgkAlgNQAkgNAjAQQAkARANAlQANAjgQAkQgRAkglANQgQAGgQAAQgTAAgUgJg");
	this.shape_9.setTransform(46,-51,0.687,0.687);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FAD6DD").s().p("AhBgSICDhFIhLCvg");
	this.shape_10.setTransform(40.1,-43.8,0.687,0.687);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FAD6DD").s().p("Ah4h6ICEhEIBtDOIhNCvg");
	this.shape_11.setTransform(26.1,-27.5,0.687,0.687);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FAD6DD").s().p("Ai8jyICQhKIDpG8IhTC9g");
	this.shape_12.setTransform(9.6,-8.4,0.687,0.687);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#EB6C85").s().p("AnIgHIORnWImlO7g");
	this.shape_13.setTransform(13.3,-17,0.687,0.687);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.8,-57.5,75.4,78.7);


(lib.eye01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A3A73").s().p("AggAgQgNgNABgTQgBgSANgNQAOgOASAAQATAAANAOQAOANAAASQAAATgOANQgNAOgTAAQgSAAgOgOg");
	this.shape.setTransform(0,0,0.687,0.687);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.1,-3.1,6.3,6.3);


(lib.calf = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#215D9E").s().p("AAUQgQgshAgIhSIkr7CQgMhyBchdQBYhZB5gMIAhgEQB0gMBrBVQBsBVAMB0IgJbDQAJBWgXBDQgiBhhgAKIgVABQhWAAg2hOg");
	this.shape.setTransform(2.6,59.9,0.687,0.687);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20.3,-17.9,45.9,155.8);


(lib.body = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4BAA75").s().p("AxbXTIAA7ZQAAkBA/jjQA+jfBzinQB0ioCbhbQChhfC6AAIHrAAQC6AACkBRQCfBOB5CQQB4COBBC6QBDC/AADUIAAebg");
	this.shape.setTransform(0,-132.4,0.838,0.687);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#215D9E").s().p("An7CaQg6gBg3geQg5gfgYgwIhhjEIY9AAIhhDEQgYAwg5AfQg3Aeg6ABg");
	this.shape_1.setTransform(-4,-15.3,1.163,1.036,0,15.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.4,-234.8,187,234.8);


(lib.ArmF = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#F9CFB9").ss(8,1,1).p("ABDgbQhNgJg4BB");
	this.shape.setTransform(-38.8,105.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#F9CFB9").ss(6,1,1).p("AAlhjQgjBUArA9AgLhjQgzBAAcCH");
	this.shape_1.setTransform(-22.7,122.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#F9CFB9").ss(7,1,1).p("ABKg+QhLAbAKCQAAHhsQhPA7gBBx");
	this.shape_2.setTransform(-36,120.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// 圖層 1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F9CFB9").s().p("Ai8LFQhIgQgXhJQgPguAHgtICbwOQAQhrBKg4QBKg5BlAXQBkAXAqBcQApBYggBpIkuPbQgNAugfAjQgnArg0AAQgPAAgQgEg");
	this.shape_3.setTransform(-9,49.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-49.5,-22,69.9,157.5);


(lib.arm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9CFB9").s().p("Ag9HHQh0hAgsiBIi9o1IKfjAICLJDQAgCFhBB0QhBB0h8AjQgsAMgrAAQhOAAhKgpg");
	this.shape.setTransform(18.9,80.3,0.687,0.687);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4BAA75").s().p("AnJgfQhAi+BLitQBLiuCrgxQCqgxCcBsQCaBsAuDDIChKqIrPDOg");
	this.shape_1.setTransform(5,16.4,0.687,0.687);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28.4,-27,75.5,141.5);


(lib.windddd = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 2
	this.instance = new lib.wind00("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-159.3,0,0.385,0.385);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).to({scaleX:1,scaleY:1,x:-159.2},10).to({startPosition:0},5).to({scaleX:0.39,scaleY:0.39,x:-159.3},5).to({_off:true},1).wait(30));

	// 圖層 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_1 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_2 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_3 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_4 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_5 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_6 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_7 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_8 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_9 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_10 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_11 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_12 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_13 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_14 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_15 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_16 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_17 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_18 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");
	var mask_graphics_19 = new cjs.Graphics().p("AtCB9Qg0gzAAhJQAAhKAygyQAzg1BJAAQA6AAAtAfQAvAhATA0IglAOQgPgogkgaQgkgZgqAAQg6AAgpAqQgnAmAAA6QAAA5ApAoQAoAoA6AAIY7AAIAAAnI47AAIgFAAQhGAAgzg0g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_1,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_2,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_3,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_4,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_5,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_6,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_7,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_8,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_9,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_10,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_11,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_12,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_13,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_14,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_15,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_16,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_17,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_18,x:-88.6,y:0}).wait(1).to({graphics:mask_graphics_19,x:-88.6,y:0}).wait(11).to({graphics:null,x:0,y:0}).wait(30));

	// 圖層 3
	this.instance_1 = new lib.windqq();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-126.8,6.4,0.206,1,95.3,0,0,-0.5,0.1);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(9).to({_off:false},0).to({regX:-0.1,scaleX:0.22,scaleY:1.23,rotation:0,skewX:136.1,skewY:142.3,x:-133.7,y:17.9},2).to({regX:-0.4,scaleX:0.22,scaleY:1.52,skewX:124.8,skewY:134.1,x:-137,y:10.1},1).to({regX:-0.1,regY:0,scaleX:0.23,scaleY:1.39,skewX:134.7,skewY:147.2,x:-140.2,y:11.4},1).to({regX:-0.6,regY:-0.1,scaleX:0.25,scaleY:1.15,rotation:-134.8,skewX:0,skewY:0,x:-160.4,y:18.9},6).to({regX:-0.7,rotation:-108,x:-159,y:4.9},5).to({regX:-0.6,scaleX:0.08,rotation:-92.5,x:-152.9,y:10.8},5).to({_off:true},1).wait(30));

	// 圖層 4
	this.instance_2 = new lib.windqq();
	this.instance_2.parent = this;
	this.instance_2.setTransform(34.8,12.4,0.044,1);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:-0.2,scaleX:0.92,x:-140.3,y:6.4},9).to({regX:-0.1,regY:-0.1,scaleX:0.87,scaleY:1.37,x:-190.7,y:-2.6},10).to({regX:-0.6,regY:-0.3,scaleX:0.29,rotation:26.2,x:-183.6,y:-27.5},5).to({regX:-0.7,scaleX:0.17,scaleY:0.98,rotation:15.6,x:-173.2,y:-25.4},2).to({regX:-2,regY:0.1,scaleX:0.15,scaleY:0.65,rotation:97.9,x:-144.8,y:-22.8},1).to({regX:0.2,scaleX:0.13,scaleY:0.67,rotation:159,x:-129.3,y:-1.1},2).to({_off:true},1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.wind001 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AwcMZIAA4xMAg5AAAIAAYxg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-33.3,y:-0.8}).wait(32).to({graphics:null,x:0,y:0}).wait(28));

	// windddd
	this.instance = new lib.windddd("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(36.1,28.6,1,1,0,180,0,-88.7,0);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({_off:false},0).to({_off:true},30).wait(28));

	// windddd
	this.instance_1 = new lib.windddd("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(49.6,-28.5,1,1,0,0,0,-88.7,0);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({_off:true},31).wait(28));

	// windddd
	this.instance_2 = new lib.windddd("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-1.8,-15.4,1,1,0,0,0,-88.7,0);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},32).wait(28));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.face2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 5
	this.instance = new lib.eye01("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-21.9,1.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},5).wait(55));

	// 圖層 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A3A73").s().p("AgvANQgVgFAAgIQAAgHAVgGQATgFAcAAQAdAAATAFQAVAGAAAHQAAAIgVAFQgTAGgdAAQgcAAgTgGg");
	this.shape.setTransform(-19.9,2.8,0.687,0.687);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(5).to({_off:false},0).to({_off:true},45).wait(10));

	// 圖層 3
	this.instance_1 = new lib.mouth01("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-15.5,20.9,1.648,1.862);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:-0.1,regY:0.1,scaleX:0.38,scaleY:0.43,x:-22.1,y:23.1},4).to({_off:true},1).wait(55));

	// 圖層 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D1A086").ss(1,1,1).p("AAsBPQgXgEgUgOQgjgZgIgqQgGgnAUgh");
	this.shape_1.setTransform(-21.4,21.8);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(5).to({_off:false},0).to({_off:true},45).wait(10));

	// 圖層 4
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F9CFB9").s().p("AgsAxQgRgJgGgSQgGgSAJgQQAIgRASgFIAxgQQASgGARAIQAQAJAGASQAGASgJAQQgIARgSAGIgwAQQgHACgHAAQgLAAgKgFg");
	this.shape_2.setTransform(-25.1,25,0.52,0.52);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F9CFB9").s().p("AgRAgQgNAAgJgKQgJgJAAgNQAAgMAJgJQAJgKANABIAjAAQANgBAJAKQAJAJAAAMQAAANgJAJQgJAKgNAAg");
	this.shape_3.setTransform(-26.7,21,0.757,0.757);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},5).to({state:[]},45).wait(10));

	// 圖層 1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F9CFB9").s().p("AgYBLQgfAAgWgWQgWgWAAgfQAAgeAWgWQAWgWAfAAIAxAAQAfAAAWAWQAWAWAAAeQAAAfgWAWQgWAWgfAAg");
	this.shape_4.setTransform(-30.1,10.7,0.687,0.687);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F9CFB9").s().p("AhFBLQgfgdgCgqQgBgqAdgfQAdgfAqgCQAqgBAfAdQAfAdACAqQABAqgdAfQgdAfgqABIgFABQgnAAgdgcg");
	this.shape_5.setTransform(6,8.4,0.687,0.687);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1A3A73").s().p("ACqHiQgYgJgPgTQgOgRgJgZQgFgPgIgfQgLgrAAgaQgCgnARgaIAFgHIh/iLIgMAbIgBADIgDAGQgGANgMAIQgNAIgOAAQgWAAgOgQQgPgQACgVIAMiMIAAgJQgBghgZgXQgZgXghABQg0AEgaAAQgvABgegNQgBgBgBAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQg7gKgpg0QgmgvgIg+QgIhAAdgtQAggyBEgHQAigDAuAeQA2AkAXAEQAtAIA+gjQBKgrAcgFQAtgIAqAZQAsAbgEArIgCANQgBAIABAFQAHAgA9gHQBHgJA6AMQBFANAsAoQAmAigMBJQgJAvgbBJQgKAaAIAUQAGAQAXAVQAnAkAVApQAYAvgDAuQgEAygnAkQgpAlgugKIgRgEQghgEgRAHQgGACgIAGQgNAVgKANQgJAYgLA2QgOAtgcANQgLAFgMAAQgLAAgLgEg");
	this.shape_6.setTransform(1.8,-1.5,0.687,0.687);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F9CFB9").s().p("AkPElQh6hxgGilQgEhnAvhcQAthZBSg5QBWg8BogLIAZgCQAugCA1ALIABAAQAlAIAhAPQBqAsBCBeQBDBhAFB2QADBQgdBLQgbBJg0A4QgUAXgcAWQhmBQiCAFIgPAAQicAAhzhrg");
	this.shape_7.setTransform(-3.2,7.4,0.687,0.687);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4}]}).to({state:[]},50).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.9,-34.9,73.8,69.8);


(lib.face = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 3
	this.instance = new lib.mouth01("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-21.5,22.5,0.433,0.433);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.65,scaleY:1.86,x:-15.5,y:20.9},10).to({_off:true},1).wait(29));

	// 圖層 2
	this.instance_1 = new lib.eye01("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-21.9,1.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},11).wait(29));

	// 圖層 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9CFB9").s().p("AgYBLQgfAAgWgWQgWgWAAgfQAAgeAWgWQAWgWAfAAIAxAAQAfAAAWAWQAWAWAAAeQAAAfgWAWQgWAWgfAAg");
	this.shape.setTransform(-30,10.7,0.687,0.687);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F9CFB9").s().p("AhFBLQgfgdgBgqQgCgqAdgfQAdgfAqgCQAqgBAfAdQAfAdACAqQABAqgdAfQgdAfgqACIgEAAQgnAAgegcg");
	this.shape_1.setTransform(6,8.3,0.687,0.687);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1A3A73").s().p("ACqHiQgXgIgQgUQgOgQgJgZQgFgPgIggQgLgrgBgaQgBgmAQgaIAGgIIh/iLIgMAcIgCADIgCAFQgGANgMAIQgMAIgPAAQgWAAgOgQQgPgQACgVIAMiMIAAgJQgBghgZgXQgZgXghABQg0AEgbAAQguABgegNIgEgBQg6gKgpgzQgmgwgIg+QgIhAAdgsQAggyBEgIQAhgDAvAfQA1AjAYAEQAtAIA+gjQBLgrAbgFQAtgIAqAaQAsAbgFArIgBANQgBAHABAFQAHAgA9gHQBHgJA6AMQBFANAsAoQAnAigOBKQgIAwgbBHQgKAaAIAUQAGAQAXAVQAmAkAWApQAYAvgDAuQgEAygnAkQgpAlgvgKIgQgEQgigEgQAHQgHACgHAGIgXAiQgJAYgLA2QgOAtgcANQgKAFgMAAQgLAAgMgEg");
	this.shape_2.setTransform(1.8,-1.5,0.687,0.687);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F9CFB9").s().p("AkPElQh6hxgGilQgEhnAvhcQAthZBSg6QBWg8BogKIAZgCQAygCAxAKIABABQAlAIAhAOQBqAtBCBeQBDBgAFB3QADBPgdBMQgbBIg0A5QgXAZgZATQhlBRiDAFIgPAAQicAAhzhrg");
	this.shape_3.setTransform(-3.2,7.4,0.687,0.687);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},11).wait(29));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.9,-34.9,73.8,69.8);


(lib.character_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.instance = new lib.wind001("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(339.5,115.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(11).to({_off:false},0).to({x:234,startPosition:9},9).to({x:56.7,startPosition:31},22).to({_off:true},2).wait(16));

	// 圖層 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFCC00").ss(1,1,1).p("AB7jrQASFAkICX");
	this.shape.setTransform(463.7,97);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFCC00").ss(1,1,1).p("Ah7DsQEIiXgSlA");
	this.shape_1.setTransform(471,95.8);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFCC00").ss(1,1,1).p("Ah7DsQEIiWgSlB");
	this.shape_2.setTransform(485.5,93.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFCC00").ss(1,1,1).p("AB7jrQASFBkICW");
	this.shape_3.setTransform(536.4,84.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFCC00").ss(1,1,1).p("AiFDvQEIiWADlH");
	this.shape_4.setTransform(527.3,85.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFCC00").ss(1,1,1).p("AiaD2QEIiXAtlU");
	this.shape_5.setTransform(509.8,87.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFCC00").ss(1,1,1).p("AC6j/QhrFokICX");
	this.shape_6.setTransform(483.9,89.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFCC00").ss(1,1,1).p("AjIEJQEIiWCIl7");
	this.shape_7.setTransform(471.1,91);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFCC00").ss(1,1,1).p("AjWETQEIiXClmO");
	this.shape_8.setTransform(458.3,92.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFCC00").ss(1,1,1).p("AjlEcQEIiWDDmh");
	this.shape_9.setTransform(445.5,94);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFCC00").ss(1,1,1).p("Aj0ElQEIiWDhmz");
	this.shape_10.setTransform(432.7,95.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FFCC00").ss(1,1,1).p("AkDEvQEIiXD/nG");
	this.shape_11.setTransform(419.9,96.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFCC00").ss(1,1,1).p("AkSE4QEJiXEbnY");
	this.shape_12.setTransform(407.1,98.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FFCC00").ss(1,1,1).p("AEhlAQk4HrkJCW");
	this.shape_13.setTransform(394.3,99.8);
	this.shape_13._off = true;

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFCC00").ss(1,1,1).p("AkgFBQDmjGFbm7");
	this.shape_14.setTransform(394.3,99.8);
	this.shape_14._off = true;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FFCC00").ss(1,1,1).p("AEhlAQl+GLjDD2");
	this.shape_15.setTransform(394.3,99.8);
	this.shape_15._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2,p:{x:485.5,y:93.4}}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2,p:{x:500.1,y:91}}]},1).to({state:[{t:this.shape_2,p:{x:507.3,y:89.7}}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_13}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).wait(1).to({x:478.2,y:94.6},0).to({_off:true},1).wait(1).to({_off:false,x:492.8,y:92.2},0).to({_off:true},1).wait(2).to({_off:false,x:514.6,y:88.5},0).wait(1).to({x:521.9,y:87.3},0).wait(1).to({x:529.1,y:86.1},0).to({_off:true},1).wait(50));
	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(20).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(21).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(22).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(1));

	// hat
	this.instance_1 = new lib.hat("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(480,71.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:551.2,y:58.7},10).to({rotation:6.5,x:505.5,y:60.8},3,cjs.Ease.get(-0.99)).to({rotation:8,x:425.2,y:64.5},7).to({rotation:26.9},2).to({rotation:8},2).to({rotation:26.9},2).to({rotation:8},2).to({rotation:26.9},2).to({rotation:8},2).to({rotation:26.9},2).to({rotation:8},2).to({rotation:26.9},2).to({rotation:8},2).to({rotation:26.9},2).to({rotation:8},2).to({rotation:26.9},2).to({rotation:8},2).to({rotation:26.9},2).to({rotation:8},2).to({rotation:26.9},2).to({rotation:8},2).to({rotation:26.9},2).to({rotation:8},1).wait(1));

	// face2
	this.instance_2 = new lib.face2("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(535.5,73.7,1,1,2.6);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({_off:false},0).to({rotation:1.6,x:478.9,y:82.9,startPosition:3},3,cjs.Ease.get(-1)).to({rotation:0.3,x:378.2,y:99.1,startPosition:10},7).wait(40));

	// face
	this.instance_3 = new lib.face("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(462.1,87.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({rotation:4.2,x:534.8,y:74.2,startPosition:10},10).to({_off:true},1).wait(49));

	// 圖層 6
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFCC00").ss(1,1,1).p("AEhlAQluG9jTDE");
	this.shape_16.setTransform(388.8,93.1);
	this.shape_16._off = true;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FFCC00").ss(1,1,1).p("AkwFHQDHjaGamz");
	this.shape_17.setTransform(390.4,92.5);
	this.shape_17._off = true;

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFCC00").ss(1,1,1).p("AFBlMQnGGqi7Dw");
	this.shape_18.setTransform(392,91.9);
	this.shape_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(20).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(21).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(22).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false},0).to({_off:true},1).wait(1));

	// neck
	this.instance_4 = new lib.neck("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(478.9,149.1,1,1,-2.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({rotation:24.2,x:517.6,y:141.1},10).to({scaleX:1.08,scaleY:1.11,rotation:0,skewX:1.3,skewY:9.8,x:485.4,y:148.7},3,cjs.Ease.get(-0.99)).to({regY:0.1,scaleX:1.21,scaleY:1.31,skewX:-39.1,skewY:-15.5,x:429,y:162.1},7).wait(40));

	// ArmF
	this.instance_5 = new lib.ArmF("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(587.4,255.6,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({rotation:38.7,x:585.4,y:255.4},10).to({scaleX:1,scaleY:1,rotation:30.8,x:577.5,y:250.5},3,cjs.Ease.get(-0.99)).to({scaleX:1,scaleY:1,rotation:-3.2,x:563.4,y:241.8},7).wait(40));

	// arm
	this.instance_6 = new lib.arm("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(532.7,172.5,1,1,-18);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({rotation:5.4,x:568.4,y:159.6},10).to({regX:0.1,regY:0.1,scaleX:1,scaleY:1,rotation:-9.8,x:538.1,y:167.4},3,cjs.Ease.get(-0.99)).to({regX:0,regY:0,scaleX:1,scaleY:1,rotation:-36.7,x:484.9,y:180.6},7).wait(40));

	// ass
	this.instance_7 = new lib.body("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(496.5,249.8,1,1.003,0,-4.6,0,0.1,-117.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({scaleY:1,skewX:5.5,x:513,y:241.8},10).to({scaleY:1.01,skewX:-2.8,x:499.9,y:246.4},3,cjs.Ease.get(-0.99)).to({scaleY:1.02,skewX:-17.8,x:469.3,y:254.3},7).wait(40));

	// 圖層 11
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#4BAA75").s().p("AlnPWQh+k/g9lnQg9llCYnDQCXnDDkgYQDjgZC3FuQC5FuAlIFQAeGihQE/g");
	this.shape_19.setTransform(460,235.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#4BAA75").s().p("Al2PXQgXgrgXgsQhokZgzk2Qg7lmCQmjIAQgrQBIjBBbhyQBuiRCHgOQAOgBANAAQDegECyFTQARAhARAiQCbFJAjG8IADA7QATFMg3ENQgTBDgZA/g");
	this.shape_20.setTransform(462,235);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#4BAA75").s().p("AmGPZIg2hOQhukdgzk9Qg8l3CbmdIASgrQBOjABlhwQBziJCNgPIAcgBQDpgHC3FPQASAhARAjQCmFNAdHFIADA8QAOFRhBERQgcA8ggA4g");
	this.shape_21.setTransform(464.1,234.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#4BAA75").s().p("AmWPaQggghgfgjQhzkigzlCQg8mJClmXIATgrQBVi/BvhuQB5iCCSgPQAOgCAOAAQD1gIC8FKQATAhASAjQCuFTAYHOQACAeABAeQAKFXhNEUQgjA0gnAxg");
	this.shape_22.setTransform(466.2,233.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#4BAA75").s().p("AmnPcIhHg6Qh5kngylJQg+maCwmRIAVgrQBbi9B6hsQB9h8CZgPIAcgCQEAgKDBFFQAUAhATAjQC4FYATHXIACA9QAFFdhYEXQgrAtguAqg");
	this.shape_23.setTransform(468.3,232.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#4BAA75").s().p("Am3PdIhRgxQh+krgylPQg+msC6mLIAWgrQBii7CEhqQCDh1CegQIAdgCQELgMDHFAQAVAhAUAkQDAFcAOHgIABA+QACFjhjEaQgzAmg1Ajg");
	this.shape_24.setTransform(470.5,231.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#4BAA75").s().p("AnIPfIhZgnQiEkwgxlVQhAm9DFmFIAYgsQBoi6CPhoQCIhuCkgQIAcgCQEXgODME7QAWAiAVAkQDKFhAJHpIAAA/QgDFohuEeQg7Aeg8Acg");
	this.shape_25.setTransform(472.6,230.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#4BAA75").s().p("AnZPgIhigdQiJk1gxlbQhBnODQl/IAZgsQBvi4CZhmQCNhnCqgRIAdgCQEigRDRE3QAXAiAVAlQDUFlAEHyIgBBAQgHFuh6EhQhCAWhDAVg");
	this.shape_26.setTransform(474.8,229.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#4BAA75").s().p("AnqPiIhrgUQiPk5gwlhQhBngDal6IAagrQB1i3CkhkQCShgCwgRIAdgDQEtgSDXEyQAYAhAWAmQDcFqgBH7QABAhgCAgQgLF0iFEkIiUAdg");
	this.shape_27.setTransform(477,229.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#4BAA75").s().p("An8PjIhzgJQiUk/gwlnQhCnxDkl0QAOgWAOgVQB8i2CuhiQCXhZC1gRIAfgDQE4gUDbEtQAZAhAYAmQDlFvgGIEQAAAhgBAhQgRF5iPEoIikAOg");
	this.shape_28.setTransform(479.2,228.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#4BAA75").s().p("AqJPlQialDgwltQhDoDDvluQCKjUDOhsQCqhZDNgNQFpgZDtFzQDvFzgLINQgKGpioFEg");
	this.shape_29.setTransform(481.5,227.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#4BAA75").s().p("AnAPkIhagSIgkgMQiMk1gzlcIAAgBQhFndDJlzIAWgmQANgXAOgUQBnifCNhcIAZgRQCHhXCigQIAXgCIABAAQEjgSDUEuQAZAjAYAoIABABQDZFlAHHyIAAA4QAAAhgBAhQgNFMhwELIhGAbIhwAbg");
	this.shape_30.setTransform(472.3,231.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#4BAA75").s().p("AmKPjIhQgkIgZgYQh/kog2lKIAAgBQhHm3Cil5IARgmIAXgsQBVilB1hiIAXgTQB5hoCVgPIAYgCIABAAQEFgPDJE5QAXAiAVAmIABABQDDFXAaHYIADA1IABBAQADE/hQEDIgsA1QgwAcgxAag");
	this.shape_31.setTransform(463.3,234.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#4BAA75").s().p("AlWPiIhGg2Qh9krg+lNIAAAAQhMmlCMmRIASgsQBJi8BrhsQBsh5CJgPIAYgCQDngMC/FEQAUAiATAlQC5FcAnHdIAFA8QAVFjhFEbQgoApgpAng");
	this.shape_32.setTransform(454.5,238.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#4BAA75").s().p("AGAOiQlTgllLgpIhKgJIg+g4QhxkigslGIAAgBQgnlHBVkNQAdhTAnhKIATgjQBMiYBphIIABAAQBkhZB9ACIAWABQDRARCrE1QASAiASAkIANAbQCTFAAhGOIgCAzIgDAzQgTExhfDyQgpAjgpAhg");
	this.shape_33.setTransform(451,244.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#4BAA75").s().p("AEVNnQkwhKkjhTIhAgTIg2g5Qhkkagbk/IAAgBQgUlOBljjQAkhGAug3IAVgZQBPhzBmgjIABAAQBeg7BvAUIATADQC+AtCXEoQAQAhAQAkIAMAaQCGFDAWF2IgKArIgLArQg6D+h6DJQgpAegqAcg");
	this.shape_34.setTransform(447.9,249.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#4BAA75").s().p("ACuMwQkOhvj6h8Ig3gcQgYgdgWgeQhYkSgKk3IAAAAQgBlVB2i6QAsg6AzgiIAYgQQBRhPBlABIAAABQBYgcBiAlIARAGQCoBKCEEZIAcBEIAKAaQB5FGALFfIgSAiIgRAiQhiDLiVChQgpAYgrAWg");
	this.shape_35.setTransform(444.5,254.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#4BAA75").s().p("ABHMNQjriTjSimIgtglQgTgfgSgfQhMkJAHkvIAAgBQATlbCGiQQA0guA5gOQANgFAMgCQBUgqBiAmIACABQBPACBXA2IAOAJQCUBnBvELQANAgAMAjIAJAYQBsFJAAFIIgaAaIgZAaQiJCYiwB5QgqASgrAQg");
	this.shape_36.setTransform(440.9,257.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#4BAA75").s().p("AgbMCQjLi4iojQIgkguQgPgfgOghQhAkAAZkoIAAgBQAmlhCWhnQA8ghA/AGQAOAAANACQBWgFBgBKIACACQBIAhBLBHIAMAMQB+CDBcD9QALAgAKAiIAIAXQBeFMgLExIghARIggARQixBmjLBRIhUAWg");
	this.shape_37.setTransform(437.1,258.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#4BAA75").s().p("Ah9MMQipjdh/j5QgOgcgNgcQgLgggKgiQgzj2AqkjIAAgBQA5lnCmg9QBEgVBGAaQAOAFAPAHQBYAfBeBvIACACQBCA/A9BZIAKAOQBpCgBIDvIASBAIAGAXQBRFQgVEZIgqAJIgnAJQjZAyjkApIhWALg");
	this.shape_38.setTransform(433.2,256.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#4BAA75").s().p("AjeMcQiGkDhXkiQhWkiBMltQBNluC2gTQC3gUC4EoQC7EpBUGiQBEFTghEDg");
	this.shape_39.setTransform(429.1,254.5);

	
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19}]}).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).wait(40));

	
	// shoe
	this.instance_8 = new lib.shoe("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(554.4,585.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({startPosition:0},10).to({startPosition:0},3,cjs.Ease.get(-0.99)).to({startPosition:0},7).wait(40));

	// calf
	this.instance_9 = new lib.calf("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(513.4,479.3,1,1,-19.4,0,0,0.1,2.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({rotation:-9.9,x:532.4,y:472.9},10).to({regY:3,scaleX:1,scaleY:1.03,rotation:-16.1,x:517.6,y:473.5},3,cjs.Ease.get(-0.99)).to({regX:0.2,scaleX:1,scaleY:1.09,rotation:-27.4,x:491.5,y:474.3},7).wait(40));

	// leg
	this.instance_10 = new lib.leg("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(546.3,345.3,1,1,2.3,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({rotation:-5.9,x:547.9,y:332.4},10).to({regX:0,regY:0,rotation:0,x:544.4,y:335.6},3,cjs.Ease.get(-0.99)).to({regX:0.1,regY:0.1,rotation:9,x:538.4,y:345.6},7).wait(40));

	// shoe
	this.instance_11 = new lib.shoe("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(431.8,585.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({startPosition:0},10).to({startPosition:0},3,cjs.Ease.get(-0.99)).to({startPosition:0},7).wait(40));

	// calf
	this.instance_12 = new lib.calf("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(407.6,469.9,1,1,-10.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({rotation:1.5,x:433.4,y:467.4},10).to({rotation:-5.3,x:418.3,y:467.9},3,cjs.Ease.get(-0.99)).to({regX:0.1,regY:0.1,rotation:-17.4,x:391.7,y:468.9},7).wait(40));

	// leg
	this.instance_13 = new lib.leg("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(441.8,339.6,1,1,2.2,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({rotation:-8.1,x:445.4,y:332.4},10).to({regX:0,regY:0,rotation:-3.4,x:441.1,y:331.6},3,cjs.Ease.get(-0.99)).to({regX:0.1,regY:0.1,rotation:5.9,x:434.6,y:341},7).wait(40));

	// ArmF
	this.instance_14 = new lib.ArmF("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(454,278.3,1,1,24.5,0,0,0.3,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({regY:0,rotation:53.1,x:439.2,y:251},10).to({regX:0.4,regY:0.1,scaleX:1,scaleY:1,rotation:51.1,x:444.6,y:261.4},3,cjs.Ease.get(-0.99)).to({scaleX:1,scaleY:1,rotation:27.5,x:454.2,y:279.4},7).wait(40));

	// arm
	this.instance_15 = new lib.arm("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(455.2,181,1,1,16.2,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({rotation:42.9,x:483.9,y:164.6},10).to({scaleX:1,scaleY:1,rotation:33.1,x:473.6,y:170.9},3,cjs.Ease.get(-0.99)).to({scaleX:1,scaleY:1,rotation:16.2,x:455.2,y:182},7).wait(40));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(358.5,13.7,249.3,595.8);


// stage content:
(lib.character = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 圖層 1
	this.instance = new lib.character_1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(110,113,1,1,0,0,0,104,109);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(679.5,332.7,249.3,595.8);
// library properties:
lib.properties = {
	id: 'C8A043064CED9B43A39BB816E5FB3600',
	width: 630,
	height: 630,
	fps: 30,
	color: "#E9FBF9",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:
(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }

p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C8A043064CED9B43A39BB816E5FB3600'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;